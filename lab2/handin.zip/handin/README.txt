The debug prompts in ddr3/arm_single.sv are required for proper execution.
Without the debug prompts, some of the flags weren't setting propely, for some reason.
Please take pity and leave them when testing on the hardware.